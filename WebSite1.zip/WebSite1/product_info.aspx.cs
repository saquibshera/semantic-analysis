﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class product_info : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            TextBox1.Text = Convert.ToString(getauto());
            bind_category();
        }
    }
    private Int32 getauto()
    {
        SqlConnection con1 = new SqlConnection();
        con1.ConnectionString = ConfigurationSettings.AppSettings["cn"];
        con1.Open();
        SqlCommand cmd1 = new SqlCommand();
        cmd1.Connection = con1;
        cmd1.CommandText = "Select isnull(max(product_id),1000) from product_info";

        return Convert.ToInt32(cmd1.ExecuteScalar()) + 1;
    }

    private void bind_category()
    {
        SqlDataAdapter adp = new SqlDataAdapter("select * from category_info order by category_id", ConfigurationSettings.AppSettings["cn"]);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        DropDownList1.DataSource = ds;
        DropDownList1.DataBind();
    }

    private void image_upload()
    {
        // Initialize variables
        string sSavePath;


        // Set constant values
        sSavePath = "images1/";


        // If file field isn’t empty
        if (FileUpload1.PostedFile != null)
        {
            // Check file size (mustn’t be 0)
            HttpPostedFile myFile = FileUpload1.PostedFile;
            int nFileLen = myFile.ContentLength;
            if (nFileLen == 0)
            {
                Label9.Text = "There wasn't any file uploaded.";
                return;
            }

            // Check file extension (must be JPG)
            if (System.IO.Path.GetExtension(myFile.FileName).ToLower() != ".jpg")
            {
                Label9.Text = "The file must have an extension of JPG";
                return;
            }

            // Read file into a data stream
            byte[] myData = new Byte[nFileLen];
            myFile.InputStream.Read(myData, 0, nFileLen);

            // Make sure a duplicate file doesn’t exist.  If it does, keep on appending an incremental numeric until it is unique
            string sFilename = System.IO.Path.GetFileName(myFile.FileName);

            // Save the stream to disk
            System.IO.FileStream newFile = new System.IO.FileStream(Server.MapPath(sSavePath + sFilename), System.IO.FileMode.Create);
            newFile.Write(myData, 0, myData.Length);
            newFile.Close();

            // Check whether the file is really a JPEG by opening it

            //  Bitmap myBitmap;


            // myBitmap = new Bitmap(Server.MapPath(sSavePath + sFilename));


            Label10.Text = sSavePath + sFilename;
            // Displaying success information
            Label9.Text = "File uploaded successfully!";

            // Destroy objects
            //   myThumbnail.Dispose();
            //myBitmap.Dispose();
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        image_upload();

        SqlConnection con19 = new SqlConnection();


        con19.ConnectionString = ConfigurationSettings.AppSettings["cn"];
        con19.Open();

        SqlCommand cmd19 = new SqlCommand();
        cmd19.CommandText = "insert into product_info values(@product_id,@product_name,@category_id,@product_description,@photo,@features,@score)";
        cmd19.Connection = con19;
        cmd19.Parameters.Add("@product_id", SqlDbType.Int).Value = Convert.ToInt32(TextBox1.Text);
        cmd19.Parameters.Add("@product_name", SqlDbType.VarChar, 200).Value = TextBox2.Text;
        cmd19.Parameters.Add("@category_id", SqlDbType.Int).Value = Convert.ToInt32(DropDownList1.SelectedValue);
        cmd19.Parameters.Add("@product_description", SqlDbType.VarChar, 2000).Value = TextBox4.Text;
        cmd19.Parameters.Add("@photo", SqlDbType.VarChar, 100).Value = Label10.Text;
        cmd19.Parameters.Add("@features", SqlDbType.VarChar, 2000).Value = TextBox5.Text;
        cmd19.Parameters.Add("@score", SqlDbType.Int).Value = 0;

        cmd19.ExecuteNonQuery();
        cmd19.Dispose();
        con19.Close();
        TextBox1.Text = Convert.ToString(getauto());
        TextBox2.Text = "";
        
        TextBox4.Text = "";
        TextBox5.Text = "";
        TextBox6.Text = "";
        

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("main.aspx");
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}