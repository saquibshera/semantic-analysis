﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class view_del_sentiment : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            bind();
        }
    }
    private void bind()
    {
        SqlDataAdapter adp = new SqlDataAdapter("select * from sentiment order by sentiment_id", ConfigurationSettings.AppSettings["cn"]);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int sentiment_id = Convert.ToInt32(((Label)(GridView1.Rows[e.RowIndex].FindControl("l1"))).Text);


        SqlConnection con = new SqlConnection();
        con.ConnectionString = ConfigurationSettings.AppSettings["cn"];
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "delete from sentiment where sentiment_id=@sentiment_id";
        cmd.Connection = con;
        cmd.Parameters.Add("@sentiment_id", SqlDbType.Int).Value = sentiment_id;


        cmd.ExecuteNonQuery();
        cmd.Dispose();
        bind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("main.aspx");
    }
}