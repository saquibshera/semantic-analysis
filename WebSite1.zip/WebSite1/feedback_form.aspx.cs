﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class feedback_form : System.Web.UI.Page
{
    string ip = "";
    int tot_times = 0;


    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
    
            bind_category();
            bind();       
            Label1.Text = Convert.ToString(getauto());
            ip = GetUserIP();                                 //ip address of client machine
    
        }

    }
    private void bind_category()
    {
        SqlDataAdapter adp = new SqlDataAdapter("select * from category_info order by category_id", ConfigurationSettings.AppSettings["cn"]);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        DropDownList1.DataSource = ds;
        DropDownList1.DataBind();
    }
    
    private string GetUserIP()
    {
        string ipList = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

        if (!string.IsNullOrEmpty(ipList))
        {
            return ipList.Split(',')[0];
        }

        return Request.ServerVariables["REMOTE_ADDR"];
    }


    private void bind()
    {
        int c_id = Convert.ToInt32(DropDownList1.SelectedValue);
        SqlDataAdapter adp = new SqlDataAdapter("select * from product_info where category_id="+c_id+"order by score desc", "server=(local);database=opinion;integrated security=true");
        DataSet ds = new DataSet();
        adp.Fill(ds);
        DataList1.DataSource = ds;
        DataList1.DataBind();
    }
    protected void DataList1_EditCommand(object source, DataListCommandEventArgs e)
    {
        DataList1.EditItemIndex = e.Item.ItemIndex;
        bind();
    }


    private Int32 getauto()
    {
        SqlConnection con1 = new SqlConnection();
        con1.ConnectionString = ConfigurationSettings.AppSettings["cn"];
        con1.Open();
        SqlCommand cmd1 = new SqlCommand();
        cmd1.Connection = con1;
        cmd1.CommandText = "Select isnull(max(feedback_id),1000) from feedback_detail";

        return Convert.ToInt32(cmd1.ExecuteScalar()) + 1;
    }
    private Int32 getauto1()
    {
        SqlConnection con1 = new SqlConnection();
        con1.ConnectionString = ConfigurationSettings.AppSettings["cn"];
        con1.Open();
        SqlCommand cmd1 = new SqlCommand();
        cmd1.Connection = con1;
        cmd1.CommandText = "Select isnull(max(id),1000) from sentiment_result";

        return Convert.ToInt32(cmd1.ExecuteScalar()) + 1;
    }

    private Int32 getauto2()
    {
        SqlConnection con1 = new SqlConnection();
        con1.ConnectionString = ConfigurationSettings.AppSettings["cn"];
        con1.Open();
        SqlCommand cmd1 = new SqlCommand();
        cmd1.Connection = con1;
        cmd1.CommandText = "Select isnull(max(id),100) from final_result";

        return Convert.ToInt32(cmd1.ExecuteScalar()) + 1;
    }



    protected void DataList1_UpdateCommand(object source, DataListCommandEventArgs e)
    {
        ip = GetUserIP();
        int product_id = Convert.ToInt32(((Label)(e.Item.FindControl("l2"))).Text);
        string review = (((TextBox)(e.Item.FindControl("t1"))).Text);
        string w="";
        string sentiment_satatus="";
       int tot_score=0;
        int id=0;
        int sentim_score=0;
        int result_id = 0;


        // to compare ip and date

                string dd = DateTime.Now.ToShortDateString();

        SqlConnection con18 = new SqlConnection();

        con18.ConnectionString = ConfigurationSettings.AppSettings["cn"];
        con18.Open();

        SqlCommand cmd18 = new SqlCommand();
        cmd18.CommandText = "SELECT count(*) as tot FROM  feedback_detail where ip_address=@ip and date_1=@dd";
        cmd18.Connection = con18;
        cmd18.Parameters.Add("@ip", SqlDbType.VarChar,50).Value =ip ;
        cmd18.Parameters.Add("@dd", SqlDbType.VarChar,50).Value = dd;
        SqlDataReader dr18;
        dr18 = cmd18.ExecuteReader();

        if (dr18.HasRows)
        {
            dr18.Read();
            tot_times = Convert.ToInt32(dr18["tot"].ToString());
        }


        cmd18.Dispose();
        con18.Close();

       
        // save entry in feedback detail after checking not more than 2 entries with same ip and same date

        if (tot_times <= 2)      // start of if condition
        {

            SqlConnection con19 = new SqlConnection();


            con19.ConnectionString = ConfigurationSettings.AppSettings["cn"];
            con19.Open();

            SqlCommand cmd19 = new SqlCommand();
            cmd19.CommandText = "insert into feedback_detail values(@feedback_id,@product_id,@feedback_review,@date_1,@ip_address,@feedback_sentiment,@feedback_score)";
            cmd19.Connection = con19;
            cmd19.Parameters.Add("@feedback_id", SqlDbType.Int).Value = Convert.ToInt32(Label1.Text);
            cmd19.Parameters.Add("@product_id", SqlDbType.Int).Value = product_id;
            cmd19.Parameters.Add("@feedback_review", SqlDbType.VarChar, 2000).Value = review;
            cmd19.Parameters.Add("@date_1", SqlDbType.VarChar, 50).Value = dd;
            cmd19.Parameters.Add("@ip_address", SqlDbType.VarChar, 50).Value = ip;
            cmd19.Parameters.Add("@feedback_sentiment", SqlDbType.VarChar, 50).Value = "NULL";

            cmd19.Parameters.Add("@feedback_score", SqlDbType.Int).Value = 0;

            cmd19.ExecuteNonQuery();
            cmd19.Dispose();
            con19.Close();
            Label1.Text = Convert.ToString(getauto());

            tot_times++;

            // find the sentiment of review

            System.Collections.ArrayList arrtext = new System.Collections.ArrayList();   //   array class
            string s1 = review;
            int WordCountn = s1.Split(' ').Length;       ///   count no. of words in review
            string[] wordsn = s1.Split(' ');

            for (int i = 0; i < WordCountn; i++)
            {
                arrtext.Add(wordsn[i]);                             // review in array
            }

            for (int j1 = 0; j1 < WordCountn; j1++)                 // starting of loop
            {

                sentim_score = 0;


                w = arrtext[j1].ToString();
                SqlConnection con12 = new SqlConnection();
                con12.ConnectionString = ConfigurationSettings.AppSettings["cn"];
                con12.Open();
                SqlCommand cmd12 = new SqlCommand();
                cmd12.CommandText = "select * from sentiment where sentiment_word like N'" + w + "%'";
                cmd12.Connection = con12;
                SqlDataReader dr12;
                dr12 = cmd12.ExecuteReader();
                if (dr12.HasRows)
                {

                    dr12.Read();

                    sentiment_satatus = dr12["status"].ToString();
                    sentim_score = Convert.ToInt32(dr12["score"].ToString());

                    if (sentiment_satatus == "negative")
                    {
                        tot_score = tot_score - sentim_score;
                    }
                    else
                    {
                        tot_score = tot_score + sentim_score;
                    }


                    // inser into sentiment_result
                    id = getauto1();

                    SqlConnection con20 = new SqlConnection();
                    con20.ConnectionString = ConfigurationSettings.AppSettings["cn"];
                    con20.Open();

                    SqlCommand cmd20 = new SqlCommand();
                    cmd20.CommandText = "insert into sentiment_result values(@product_id,@id,@sentence,@word,@sentiment_status,@score)";
                    cmd20.Connection = con20;
                    cmd20.Parameters.Add("@product_id", SqlDbType.Int).Value = product_id;
                    cmd20.Parameters.Add("@id", SqlDbType.Int).Value = id;
                    cmd20.Parameters.Add("@sentence", SqlDbType.VarChar, 2000).Value = review;
                    cmd20.Parameters.Add("@word", SqlDbType.VarChar, 50).Value = w;
                    cmd20.Parameters.Add("@sentiment_status", SqlDbType.VarChar, 50).Value = sentiment_satatus;


                    cmd20.Parameters.Add("@score", SqlDbType.Int).Value = sentim_score;

                    cmd20.ExecuteNonQuery();
                    cmd20.Dispose();
                    con20.Close();






                }
            }           //  End of loop


            string final_sentiment = "";

            if (tot_score > 0)
            {
                final_sentiment = "Positive";
            }
            else if (tot_score < 0)
            {
                final_sentiment = "Negative";
            }
            else
            {
                final_sentiment = "Neutral";
            }



            // inser into final_result
            result_id = getauto2();

            SqlConnection con21 = new SqlConnection();
            con21.ConnectionString = ConfigurationSettings.AppSettings["cn"];
            con21.Open();

            SqlCommand cmd21 = new SqlCommand();
            cmd21.CommandText = "insert into final_result values(@product_id,@sentence,@sentiment,@score,@id)";
            cmd21.Connection = con21;
            cmd21.Parameters.Add("@product_id", SqlDbType.Int).Value = product_id;

            cmd21.Parameters.Add("@sentence", SqlDbType.VarChar, 2000).Value = review;
            cmd21.Parameters.Add("@sentiment", SqlDbType.VarChar, 50).Value = final_sentiment;



            cmd21.Parameters.Add("@score", SqlDbType.Int).Value = tot_score;
            cmd21.Parameters.Add("@id", SqlDbType.Int).Value = result_id;
            cmd21.ExecuteNonQuery();
            cmd21.Dispose();
            con21.Close();





            SqlConnection con22 = new SqlConnection();
            con22.ConnectionString = ConfigurationSettings.AppSettings["cn"];
            con22.Open();

            SqlCommand cmd22 = new SqlCommand();
            cmd22.CommandText = "update feedback_detail set feedback_sentiment=@final_sentiment, feedback_score=@tot_score where feedback_sentiment = 'NULL'";
            cmd22.Connection = con22;
           
           
            cmd22.Parameters.Add("@final_sentiment", SqlDbType.VarChar, 50).Value = final_sentiment;
            cmd22.Parameters.Add("@tot_score", SqlDbType.Int).Value = tot_score;




           
            cmd22.ExecuteNonQuery();
            cmd22.Dispose();
            con22.Close();




            SqlConnection con23 = new SqlConnection();
            con23.ConnectionString = ConfigurationSettings.AppSettings["cn"];
            con23.Open();

            SqlCommand cmd23 = new SqlCommand();
            if (final_sentiment == "Positive")
            {
                cmd23.CommandText = "update product_info set score=score+ " + tot_score + "  where product_id=" + product_id;
            }
            else
            {
                cmd23.CommandText = "update product_info set score=score+ "+tot_score+" where product_id=" + product_id;
            }
            cmd23.Connection = con23;



            cmd23.Parameters.Add("@tot_score", SqlDbType.Int).Value = tot_score;






            cmd23.ExecuteNonQuery();
            cmd23.Dispose();
            con23.Close();










        }            // end of if condition to check entries count with same ip address
        else
        {
            Label3.Text = "False/Fake Feedback Review is not entertained";
        }



        DataList1.EditItemIndex = -1;
        bind();
    }
    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("main.aspx");
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        bind();
    }
}