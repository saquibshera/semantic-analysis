﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.DataVisualization.Charting;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class test_page : System.Web.UI.Page
{
    int tot_count = 0;
    int min_id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {

            bind_category();
            insert_temp();
            tot_count = getauto();
            BindChart(GetData());

        }
        
    }
    private void bind_category()
    {
        SqlDataAdapter adp = new SqlDataAdapter("select * from category_info order by category_id", ConfigurationSettings.AppSettings["cn"]);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        DropDownList1.DataSource = ds;
        DropDownList1.DataBind();
    }

    private void insert_temp()
    {
        SqlConnection con24 = new SqlConnection();
        con24.ConnectionString = ConfigurationSettings.AppSettings["cn"];
        con24.Open();

        SqlCommand cmd24 = new SqlCommand();
        cmd24.CommandText = "delete from product_info_temp ";
        cmd24.Connection = con24;
        cmd24.ExecuteNonQuery();
        cmd24.Dispose();
        con24.Close();



        SqlConnection con21 = new SqlConnection();
        con21.ConnectionString = ConfigurationSettings.AppSettings["cn"];
        con21.Open();

        SqlCommand cmd21 = new SqlCommand();
        cmd21.CommandText = "insert into product_info_temp select * from product_info where category_id="+Convert.ToInt32(DropDownList1.SelectedValue);
        cmd21.Connection = con21;
       
        cmd21.ExecuteNonQuery();
        cmd21.Dispose();
        con21.Close();

    }

    private Int32 getauto()
    {
        SqlConnection con1 = new SqlConnection();
        con1.ConnectionString = ConfigurationSettings.AppSettings["cn"];
        con1.Open();
        SqlCommand cmd1 = new SqlCommand();
        cmd1.Connection = con1;
        cmd1.CommandText = "Select isnull(count(*),0) from product_info_temp";

        return Convert.ToInt32(cmd1.ExecuteScalar()) + 1;
    }
    
      public DataTable GetData()
      {
            DataTable dtReport = new DataTable();

            dtReport.Columns.Add("Product Name", typeof(string));
            dtReport.Columns.Add("Score", typeof(int));

            string product_name = "";
            int score = 0;

            for (int i = 1; i < tot_count; i++)
            {
                SqlConnection con22 = new SqlConnection();
                con22.ConnectionString = ConfigurationSettings.AppSettings["cn"];
                con22.Open();

                SqlCommand cmd22 = new SqlCommand();
                cmd22.CommandText = "select min(product_id) as mid from product_info_temp ";
                cmd22.Connection = con22;

                SqlDataReader dr22;
                dr22 = cmd22.ExecuteReader();
                if (dr22.HasRows)
                {
                    dr22.Read();
                    min_id = Convert.ToInt32(dr22["mid"].ToString());
                }
                cmd22.Dispose();
                con22.Close();



                SqlConnection con23 = new SqlConnection();
                con23.ConnectionString = ConfigurationSettings.AppSettings["cn"];
                con23.Open();

                SqlCommand cmd23 = new SqlCommand();
                cmd23.CommandText = "select * from product_info_temp where product_id="+min_id;
                cmd23.Connection = con23;

                SqlDataReader dr23;
                dr23 = cmd23.ExecuteReader();
                if (dr23.HasRows)
                {
                    dr23.Read();
                    product_name = (dr23["product_name"].ToString());
                    score = Convert.ToInt32(dr23["score"].ToString());
                }
                cmd23.Dispose();
                con23.Close();



                dtReport.Rows.Add(product_name, score);   // add value in report

                SqlConnection con24 = new SqlConnection();
                con24.ConnectionString = ConfigurationSettings.AppSettings["cn"];
                con24.Open();

                SqlCommand cmd24 = new SqlCommand();
                cmd24.CommandText = "delete from product_info_temp where product_id=" + min_id;
                cmd24.Connection = con24;
                cmd24.ExecuteNonQuery();
                cmd24.Dispose();
                con24.Close();


                          }


            return dtReport;
      }
      public void BindChart(DataTable dtReport)
      {
          string[] x = new string[dtReport.Rows.Count];
          double[] y = new double[dtReport.Rows.Count];
          for (int i = 0; i < dtReport.Rows.Count; i++)
          {
              x[i] = dtReport.Rows[i][0].ToString();
              y[i] = Convert.ToDouble(dtReport.Rows[i][1]);
          }
          chart1.Series[0].Points.DataBindXY(x, y);

          // Pie Chart
          chart1.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Pie;

          // Line Chart
          chart1.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Line;

          //Bar Chart
          chart1.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Bar;

          //Pyramid
          chart1.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Pyramid;



          chart1.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Column;

          chart1.ChartAreas["ChartArea1"].AxisX.LabelStyle.Angle = -50;
          chart1.ChartAreas["ChartArea1"].AxisX.TitleFont = new System.Drawing.Font("Verdana", 8, System.Drawing.FontStyle.Bold);
          chart1.ChartAreas["ChartArea1"].AxisY.TitleFont = new System.Drawing.Font("Verdana", 8, System.Drawing.FontStyle.Bold);
          chart1.ChartAreas["ChartArea1"].AxisX.Minimum = 0;
          chart1.ChartAreas["ChartArea1"].AxisX.Interval = 1;
          chart1.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = true;
          //chart1.ChartAreas["ChartArea1"].AxisX.MajorGrid.LineColor = ColorTranslator.FromHtml("#e5e5e5");
          chart1.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = true;
          //chart1.ChartAreas["ChartArea1"].AxisY.MajorGrid.LineColor = ColorTranslator.FromHtml("#e5e5e5");
          //chart1.ChartAreas["ChartArea1"].AxisX.LabelStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);
          //chart1.ChartAreas["ChartArea1"].AxisY.LabelStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);
          chart1.Series[0].IsValueShownAsLabel = true;
          chart1.ChartAreas["ChartArea1"].AxisY.Title = "Score";
          chart1.ChartAreas["ChartArea1"].AxisX.Title = "Product Name";
          chart1.Width = 500;
      }
     
      protected void DropDownList1_SelectedIndexChanged1(object sender, EventArgs e)
      {
          insert_temp();
          tot_count = getauto();
          BindChart(GetData());
      }
      protected void Button1_Click(object sender, EventArgs e)
      {
          Response.Redirect("main.aspx");
      }
}