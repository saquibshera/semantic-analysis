﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.DataVisualization.Charting;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class prod_graph : System.Web.UI.Page

{

    protected void Page_Load(object sender, EventArgs e)
    {
        {
            if (Page.IsPostBack == false)
            {
                bind_category();
                bind_product();
                //insert_temp();
                //tot_count = getauto();
                
            }
        }
    }
    private void bind_category()
    {
        SqlDataAdapter adp = new SqlDataAdapter("select * from category_info order by category_id", ConfigurationSettings.AppSettings["cn"]);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        DropDownList1.DataSource = ds;
        DropDownList1.DataBind();
        
    }
    
            
    
    private void bind_product()
    {
        int cid = Convert.ToInt32(DropDownList1.SelectedValue);
        SqlDataAdapter adp = new SqlDataAdapter("select * from product_info where category_id="+cid, ConfigurationSettings.AppSettings["cn"]);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        DropDownList2.DataSource = ds;
        DropDownList2.DataBind();
        
    }
    private void result1()
    {
        SqlConnection con14 = new SqlConnection();
        con14.ConnectionString = "server=(local);database=opinion;integrated security=true";
        con14.Open();
        SqlCommand cmd14 = new SqlCommand();
        cmd14.CommandText = "select * from feedback_detail s order by feedback_id";
        cmd14.Connection = con14;
        SqlDataReader dr14;
        dr14 = cmd14.ExecuteReader();
        //if (dr14.HasRows)
        //{
        //    dr14.Read();

        //    if (dr14["res2"].ToString() != "")
        //    {
        //        alWeight[1] = Convert.ToInt32(dr14["res2"].ToString());
        //    }
        //    else
        //    {
        //        alWeight[1] = 0;
        //    }
        //    dr14.Close();
        //}
        cmd14.Dispose();
        con14.Close();


        SqlConnection con15 = new SqlConnection();
        con15.ConnectionString = "server=(local);database=opinion;integrated security=true";
        con15.Open();
        SqlCommand cmd15 = new SqlCommand();
        cmd15.CommandText = "select COUNT(*) as tot_review, isnull(SUM(feedback_score),0) as tot from feedback_detail where product_id=" + Convert.ToInt32(DropDownList2.SelectedValue);
        cmd15.Connection = con15;
        SqlDataReader dr15;
        dr15 = cmd15.ExecuteReader();
        if (dr15.HasRows)
        {
            dr15.Read();

            //label14.Text = (dr13["neg_value"].ToString());
            //st = (dr15["tot_value"].ToString());


            TextBox6.Text = (dr15["tot"].ToString());
            
                TextBox1.Text = (dr15["tot_review"].ToString());
            }
            else
            {
                TextBox1.Text = "0";
            }
            dr15.Close();
        

        cmd15.Dispose();
        con15.Close();



        
        SqlConnection con13 = new SqlConnection();
        con13.ConnectionString = "server=(local);database=opinion;integrated security=true";
        con13.Open();
        SqlCommand cmd13 = new SqlCommand();
        cmd13.CommandText = "select COUNT(*) as neg_value, isnull(SUM(feedback_score),0) as tot from feedback_detail where feedback_score <0 and product_id=" + Convert.ToInt32(DropDownList2.SelectedValue);
        cmd13.Connection = con13;
        SqlDataReader dr13;
        dr13 = cmd13.ExecuteReader();
        if (dr13.HasRows)
        {
            dr13.Read();

                TextBox3.Text = (dr13["neg_value"].ToString());
                TextBox8.Text = (dr13["tot"].ToString());
            }
            else
            {
                TextBox3.Text = "0";
                TextBox8.Text = "0";
            }
            dr13.Close();
        
        cmd13.Dispose();
        con13.Close();


        SqlConnection con16 = new SqlConnection();
        con16.ConnectionString = "server=(local);database=opinion;integrated security=true";
        con16.Open();
        SqlCommand cmd16 = new SqlCommand();
        cmd16.CommandText = "select COUNT(*) as neut_value, isnull(SUM(feedback_score),0) as tot from feedback_detail where feedback_score =0 and product_id=" + Convert.ToInt32(DropDownList2.SelectedValue); ;
        cmd16.Connection = con16;
        SqlDataReader dr16;
        dr16 = cmd16.ExecuteReader();
        if (dr16.HasRows)
        {
            dr16.Read();

            TextBox9.Text = (dr16["tot"].ToString());
            TextBox4.Text = (dr16["neut_value"].ToString());

            }
            else
            {
                TextBox4.Text = "0";
                TextBox9.Text = "0";
            }
            dr16.Close();
        
        cmd16.Dispose();
        con16.Close();



        TextBox2.Text = Convert.ToString(Convert.ToInt32(TextBox1.Text) - (Convert.ToInt32(TextBox3.Text)+Convert.ToInt32(TextBox4.Text)));
        TextBox7.Text = Convert.ToString(Convert.ToInt32(TextBox6.Text) - (Convert.ToInt32(TextBox8.Text)+Convert.ToInt32(TextBox9.Text)));
       


    }


    public DataTable GetData()
      {
            DataTable dtReport = new DataTable();

            dtReport.Columns.Add("Review", typeof(string));
            dtReport.Columns.Add("Count", typeof(int));


 dtReport.Rows.Add("Positive", TextBox2.Text);
 dtReport.Rows.Add("Negative", TextBox3.Text);
 dtReport.Rows.Add("Neutral", TextBox4.Text);


            return dtReport;

      }
    public DataTable GetData1()
    {
        DataTable dtReport = new DataTable();

        dtReport.Columns.Add("Score", typeof(string));
        dtReport.Columns.Add("Count", typeof(int));


        dtReport.Rows.Add("Positive", TextBox7.Text);
        dtReport.Rows.Add("Negative", TextBox8.Text);
        dtReport.Rows.Add("Neutral", TextBox9.Text);


        return dtReport;

    }
    public void BindChart1(DataTable dtReport)
    {
        string[] x = new string[dtReport.Rows.Count];
        double[] y = new double[dtReport.Rows.Count];
        for (int i = 0; i < dtReport.Rows.Count; i++)
        {
            x[i] = dtReport.Rows[i][0].ToString();
            y[i] = Convert.ToDouble(dtReport.Rows[i][1]);
        }
        chart1.Series[0].Points.DataBindXY(x, y);

        //// Pie Chart
        //chart1.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Pie;

        //// Line Chart
        //chart1.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Line;

        ////Bar Chart
        //chart1.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Bar;

        ////Pyramid
        //chart1.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Pyramid;



        chart1.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Line;

        chart1.ChartAreas["ChartArea1"].AxisX.LabelStyle.Angle = -50;
        chart1.ChartAreas["ChartArea1"].AxisX.TitleFont = new System.Drawing.Font("Verdana", 8, System.Drawing.FontStyle.Bold);
        chart1.ChartAreas["ChartArea1"].AxisY.TitleFont = new System.Drawing.Font("Verdana", 8, System.Drawing.FontStyle.Bold);
        chart1.ChartAreas["ChartArea1"].AxisX.Minimum = 0;
        chart1.ChartAreas["ChartArea1"].AxisX.Interval = 1;
        chart1.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = true;
        //chart1.ChartAreas["ChartArea1"].AxisX.MajorGrid.LineColor = ColorTranslator.FromHtml("#e5e5e5");
        chart1.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = true;
        //chart1.ChartAreas["ChartArea1"].AxisY.MajorGrid.LineColor = ColorTranslator.FromHtml("#e5e5e5");
        //chart1.ChartAreas["ChartArea1"].AxisX.LabelStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);
        //chart1.ChartAreas["ChartArea1"].AxisY.LabelStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);
        chart1.Series[0].IsValueShownAsLabel = true;
        chart1.ChartAreas["ChartArea1"].AxisY.Title = "Count";
        chart1.ChartAreas["ChartArea1"].AxisX.Title = "Reviews";
        chart1.Width = 500;
    }
    public void BindChart2(DataTable dtReport)
    {
        string[] x = new string[dtReport.Rows.Count];
        double[] y = new double[dtReport.Rows.Count];
        for (int i = 0; i < dtReport.Rows.Count; i++)
        {
            x[i] = dtReport.Rows[i][0].ToString();
            y[i] = Convert.ToDouble(dtReport.Rows[i][1]);
        }
        chart2.Series[0].Points.DataBindXY(x, y);

        //// Pie Chart
        //chart1.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Pie;

        //// Line Chart
        //chart1.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Line;

        ////Bar Chart
        //chart1.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Bar;

        ////Pyramid
        //chart1.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Pyramid;



        chart2.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Column;

        chart2.ChartAreas["ChartArea1"].AxisX.LabelStyle.Angle = -50;
        chart2.ChartAreas["ChartArea1"].AxisX.TitleFont = new System.Drawing.Font("Verdana", 8, System.Drawing.FontStyle.Bold);
        chart2.ChartAreas["ChartArea1"].AxisY.TitleFont = new System.Drawing.Font("Verdana", 8, System.Drawing.FontStyle.Bold);
        chart2.ChartAreas["ChartArea1"].AxisX.Minimum = 0;
        chart2.ChartAreas["ChartArea1"].AxisX.Interval = 1;
        chart2.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = true;
        //chart1.ChartAreas["ChartArea1"].AxisX.MajorGrid.LineColor = ColorTranslator.FromHtml("#e5e5e5");
        chart2.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = true;
        //chart1.ChartAreas["ChartArea1"].AxisY.MajorGrid.LineColor = ColorTranslator.FromHtml("#e5e5e5");
        //chart1.ChartAreas["ChartArea1"].AxisX.LabelStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);
        //chart1.ChartAreas["ChartArea1"].AxisY.LabelStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);
        chart2.Series[0].IsValueShownAsLabel = true;
        chart2.ChartAreas["ChartArea1"].AxisY.Title = "Count";
        chart2.ChartAreas["ChartArea1"].AxisX.Title = "Score";
        chart2.Width = 500;
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        bind_product();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        Response.Redirect("main.aspx");
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        result1();
        BindChart1(GetData());
        BindChart2(GetData1());
       
    }
}