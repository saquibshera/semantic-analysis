﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class main : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("category_info.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("view_category.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("product_info.aspx");
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("view_product.aspx");
    }
    protected void Button7_Click(object sender, EventArgs e)
    {
        Response.Redirect("view_del_sentiment.aspx");
    }
    protected void Button11_Click(object sender, EventArgs e)
    {
        Response.Redirect("login.aspx");
    }
    protected void Button9_Click(object sender, EventArgs e)
    {
        Response.Redirect("del_product.aspx");
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("feedback_form.aspx");
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        Response.Redirect("view_del_feedback.aspx");
    }
    protected void Button10_Click(object sender, EventArgs e)
    {
        Response.Redirect("add_sentiment.aspx");
    }
    protected void Button8_Click(object sender, EventArgs e)
    {
        Response.Redirect("view_del_sentiment_result.aspx");
    }
    protected void Button12_Click(object sender, EventArgs e)
    {
        Response.Redirect("graph_asp_net.aspx");
    }
    protected void Button13_Click(object sender, EventArgs e)
    {
        Response.Redirect("prod_graph.aspx");
    }
}