﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        SqlConnection con17 = new SqlConnection();
        con17.ConnectionString = ConfigurationSettings.AppSettings["cn"];
        con17.Open();

        SqlCommand cmd17 = new SqlCommand();
        cmd17.CommandText = "select *  from login where login=@u and password=@p";
        cmd17.Connection = con17;

        cmd17.Parameters.Add("@u", SqlDbType.VarChar, 50).Value = TextBox1.Text;
        cmd17.Parameters.Add("@p", SqlDbType.VarChar, 50).Value = TextBox2.Text;
        SqlDataReader dr17;
        dr17 = cmd17.ExecuteReader();
        if (dr17.HasRows)
        {
            Response.Redirect("main.aspx");
        }
        else
        {
            Label4.Text = "Username or Password invalid";
            TextBox1.Text = "";
            TextBox2.Text = "";
        }
        cmd17.Dispose();
        con17.Close();
    }
}