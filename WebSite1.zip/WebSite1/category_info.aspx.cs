﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class category_info : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            TextBox1.Text = Convert.ToString(getauto());
        }
    }
    private Int32 getauto()
    {
        SqlConnection con1 = new SqlConnection();
        con1.ConnectionString = ConfigurationSettings.AppSettings["cn"];
        con1.Open();
        SqlCommand cmd1 = new SqlCommand();
        cmd1.Connection = con1;
        cmd1.CommandText = "Select isnull(max(category_id),1000) from category_info";

        return Convert.ToInt32(cmd1.ExecuteScalar()) + 1;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con19 = new SqlConnection();
       

        con19.ConnectionString = ConfigurationSettings.AppSettings["cn"];
        con19.Open();

        SqlCommand cmd19 = new SqlCommand();
        cmd19.CommandText = "insert into category_info values(@category_id,@category)";
        cmd19.Connection = con19;
        cmd19.Parameters.Add("@category_id", SqlDbType.Int).Value = Convert.ToInt32(TextBox1.Text);
        cmd19.Parameters.Add("@category", SqlDbType.VarChar, 100).Value = TextBox2.Text;

        cmd19.ExecuteNonQuery();
        cmd19.Dispose();
        con19.Close();
        TextBox1.Text = Convert.ToString(getauto());
        TextBox2.Text = "";
        

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("main.aspx");
    }
}